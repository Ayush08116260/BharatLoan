# Bharat Loan 2.0 — Complete prototype

Included: loan application, EMI calculator, profile, KYC document picker, optional contacts permission, loan status, repayment placeholder, and demo admin dashboard.

This package is an Android source project, not a production lending system. It intentionally does not silently collect contacts/gallery data, process real payments, approve real loans, or store customer data on a server. Production deployment requires secure backend, authentication/OTP provider, KYC and privacy controls, payment/disbursement integration, audit logging, and applicable RBI/regulated-lender compliance.
